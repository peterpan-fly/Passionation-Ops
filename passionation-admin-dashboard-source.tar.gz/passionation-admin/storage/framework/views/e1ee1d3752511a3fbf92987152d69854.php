<div <?php echo e($attributes->class(['fi-dropdown-list'])); ?>>
    <?php echo e($slot); ?>

</div>
<?php /**PATH /Users/peterphang/Documents/Codex/2026-06-03/sites-plugin-sites-openai-bundled-go/work/passionation-admin/vendor/filament/support/resources/views/components/dropdown/list/index.blade.php ENDPATH**/ ?>