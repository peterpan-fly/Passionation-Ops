<div
    <?php echo e($attributes
            ->merge([
                'id' => $getId(),
            ], escape: false)
            ->merge($getExtraAttributes(), escape: false)); ?>

>
    <?php echo e($getChildSchema()); ?>

</div>
<?php /**PATH /Users/peterphang/Documents/Codex/2026-06-03/sites-plugin-sites-openai-bundled-go/work/passionation-admin/vendor/filament/schemas/resources/views/components/grid.blade.php ENDPATH**/ ?>