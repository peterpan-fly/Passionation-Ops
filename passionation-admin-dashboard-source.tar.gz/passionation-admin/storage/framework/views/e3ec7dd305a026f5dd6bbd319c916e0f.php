<div
    <?php echo e($attributes->gridColumn($this->getColumnSpan(), $this->getColumnStart())->class(['fi-wi-widget'])); ?>

>
    <?php echo e($slot); ?>

</div>
<?php /**PATH /Users/peterphang/Documents/Codex/2026-06-03/sites-plugin-sites-openai-bundled-go/work/passionation-admin/vendor/filament/widgets/resources/views/components/widget.blade.php ENDPATH**/ ?>