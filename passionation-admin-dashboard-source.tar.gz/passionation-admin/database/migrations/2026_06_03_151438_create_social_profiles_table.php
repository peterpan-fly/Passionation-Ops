<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('social_profiles', function (Blueprint $table) {
            $table->id();
            $table->foreignId('creator_application_id')->constrained()->cascadeOnDelete();
            $table->string('platform')->index();
            $table->string('handle')->nullable();
            $table->string('url')->nullable();
            $table->unsignedInteger('followers')->default(0);
            $table->decimal('engagement_rate', 5, 2)->nullable();
            $table->boolean('is_primary')->default(false);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('social_profiles');
    }
};
